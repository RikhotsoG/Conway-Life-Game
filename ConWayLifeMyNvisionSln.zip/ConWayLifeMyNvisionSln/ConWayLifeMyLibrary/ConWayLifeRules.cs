﻿using System;

namespace ConWayLifeMyLibrary
{
    public enum CellStatus
    {
        // Constants
        Alive,
        Dead,
    }
    public class ConWayLifeRules
    {
        public static CellStatus GetCurrentState(CellStatus CurrentCellStatus, int LiveNeighbours)
        {
            if (CurrentCellStatus == CellStatus.Alive && (LiveNeighbours < 2 || LiveNeighbours > 3))
                return CellStatus.Dead;

            if (CurrentCellStatus == CellStatus.Dead && LiveNeighbours == 3)
                return CellStatus.Alive;

            return CurrentCellStatus;
        }
    }
}
