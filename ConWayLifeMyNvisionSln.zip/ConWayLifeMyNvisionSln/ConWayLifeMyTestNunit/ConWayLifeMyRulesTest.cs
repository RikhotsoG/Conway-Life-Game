﻿using ConWayLifeMyLibrary;
using NUnit.Framework;
using System;

namespace ConWayLifeMyTestNunit
{
    // Testing rules using Nunit
    [TestFixture]
    public class ConWayLifeMyRulesTest
    {
        //1. Any live cell with fewer than two live neighbours dies, as if by underpopulation.
        [Test]
        public void Has_Fewer_Than2LiveNeighbours_Dies([Values(0, 1)] int LiveNeighbours)
        {

            // Initial State
            var CurrentCellStatus = CellStatus.Alive;

            // Test State
            CellStatus FutureCellState = ConWayLifeRules.GetCurrentState(CurrentCellStatus, LiveNeighbours);

            // Assert
            Assert.AreEqual(CellStatus.Dead, FutureCellState);
        }

        //2. Any live cell with two or three live neighbours lives on to the next generation.
        [Test]
        public void Has_Twoo_or_three_LiveNeighbours_Lives([Values(2, 3)] int LiveNeighbours)
        {
            // Initial State
            var CurrentCellStatus = CellStatus.Alive;

            // Test State
            CellStatus FutureCellState = ConWayLifeRules.GetCurrentState(CurrentCellStatus, LiveNeighbours);

            //Assert
            Assert.AreEqual(CellStatus.Alive, FutureCellState);
        }

        //3. Any live cell with more than three live neighbours dies, as if by overpopulation.
        [Test]
        public void Has_More_than_three_LiveNeighbours_Dies([Range(4, 20)] int LiveNeighbours)
        {
            // Initial State
            var CurrentCellStatus = CellStatus.Alive;

            // Test State
            CellStatus FutureCellState = ConWayLifeRules.GetCurrentState(CurrentCellStatus, LiveNeighbours);

            //Assert
            Assert.AreEqual(CellStatus.Dead, FutureCellState);
        }

        //4. Any dead cell with three live neighbours becomes a live cell, as if by reproduction. 
        [Test]
        public void Has_three_LiveNeighbours_Lives()
        {
            // Initial State
            var LiveNeighbours = 3;
            var CurrentCellStatus = CellStatus.Dead;

            // Test State
            CellStatus FutureCellState = ConWayLifeRules.GetCurrentState(CurrentCellStatus, LiveNeighbours);

            //Assert
            Assert.AreEqual(CellStatus.Alive, FutureCellState);
        }
    }
}
